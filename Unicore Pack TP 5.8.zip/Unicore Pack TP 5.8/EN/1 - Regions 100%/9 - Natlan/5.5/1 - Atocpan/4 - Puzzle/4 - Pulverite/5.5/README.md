<body>
  <div align="center">
    <h1>𝑫𝙚𝒕𝙖𝒊𝙡𝒔</h1>
    <p>Pulverite</p>
    <img src=https://raw.githubusercontent.com/Minato0211/minato-jsons/main/assets/unknown.webp>
    <h1>𝘿𝒐𝙬𝒏𝙡𝒐𝙖𝒅</h1>
    <a href="json/json.zip">json/json.zip</a></br>
  </div>
</body>
